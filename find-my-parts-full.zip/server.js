// server.js
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const fetch = require('node-fetch');
const cors = require('cors');
const FormData = require('form-data');

const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(UPLOAD_DIR));

const db = new sqlite3.Database(path.join(__dirname, 'data.sqlite'));

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    phone TEXT,
    make TEXT,
    model TEXT,
    year TEXT,
    part TEXT,
    image_path TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
});

async function sendToWhatsAppCloud({ imagePath, messageText, phoneToSend }) {
  const token = process.env.WHATSAPP_TOKEN;
  const phoneId = process.env.WHATSAPP_PHONE_NUMBER_ID;

  if (!token || !phoneId) 
    return { ok: false, reason: 'No WhatsApp Cloud API credentials configured' };

  try {
    const fileStream = fs.createReadStream(imagePath);
    const uploadUrl = `https://graph.facebook.com/v17.0/${phoneId}/media`;
    const formData = new FormData();
    formData.append('file', fileStream);
    formData.append('messaging_product', 'whatsapp');

    const uploadRes = await fetch(uploadUrl, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: formData
    });
    const uploadJson = await uploadRes.json();
    if (!uploadRes.ok) return { ok: false, reason: uploadJson };

    const mediaId = uploadJson.id;

    const sendUrl = `https://graph.facebook.com/v17.0/${phoneId}/messages`;
    const body = {
      messaging_product: 'whatsapp',
      to: phoneToSend,
      type: 'image',
      image: { id: mediaId, caption: messageText }
    };

    const sendRes = await fetch(sendUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify(body)
    });
    const sendJson = await sendRes.json();
    if (!sendRes.ok) return { ok: false, reason: sendJson };

    return { ok: true, result: sendJson };
  } catch (err) {
    return { ok: false, reason: err.message };
  }
}

app.post('/api/request', upload.single('image'), async (req, res) => {
  try {
    const { name = '', phone = '', make = '', model = '', year = '', part = '' } = req.body;
    const image = req.file ? `/uploads/${req.file.filename}` : null;

    const stmt = db.prepare(`INSERT INTO requests (name, phone, make, model, year, part, image_path) 
      VALUES (?, ?, ?, ?, ?, ?, ?)`);

    stmt.run(name, phone, make, model, year, part, image, function (err) {
      if (err) return res.status(500).json({ ok: false, error: 'DB insert failed' });

      const insertedId = this.lastID;
      const messageText = `New part request:
Name: ${name}
Phone: ${phone}
Make: ${make}
Model: ${model}
Year: ${year}
Part: ${part}
Request ID: ${insertedId}`;

      const adminNumber = process.env.ADMIN_WHATSAPP_NUMBER || '+260972750066';

      if (req.file && process.env.WHATSAPP_TOKEN && process.env.WHATSAPP_PHONE_NUMBER_ID) {
        sendToWhatsAppCloud({ 
          imagePath: path.join(__dirname, req.file.path), 
          messageText, 
          phoneToSend: adminNumber 
        })
        .then(result => {
          if (result.ok) {
            return res.json({ ok: true, id: insertedId, whatsapp: 'sent', details: result.result });
          } else {
            const waLink = `https://wa.me/${adminNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
              messageText + (image ? '\nImage: ' + (req.protocol + '://' + req.get('host') + image) : '')
            )}`;
            return res.json({ ok: true, id: insertedId, whatsapp: 'failed_send', reason: result.reason, wa_link: waLink });
          }
        })
        .catch(err => {
          const waLink = `https://wa.me/${adminNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
            messageText + (image ? '\nImage: ' + (req.protocol + '://' + req.get('host') + image) : '')
          )}`;
          return res.json({ ok: true, id: insertedId, whatsapp: 'error', reason: err.message, wa_link: waLink });
        });
      } else {
        const waLink = `https://wa.me/${adminNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
          messageText + (image ? '\nImage: ' + (req.protocol + '://' + req.get('host') + image) : '')
        )}`;
        return res.json({ ok: true, id: insertedId, whatsapp: 'not_configured', wa_link: waLink });
      }
    });
    stmt.finalize();
  } catch (err) {
    res.status(500).json({ ok: false, error: 'Server error' });
  }
});

app.get('/api/requests', (req, res) => {
  db.all('SELECT * FROM requests ORDER BY created_at DESC LIMIT 200', [], (err, rows) => {
    if (err) return res.status(500).json({ ok: false, error: err.message });
    res.json({ ok: true, requests: rows });
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Find-My-Parts app running on http://localhost:${PORT}`));
